#include <iostream>
#include <string>

using namespace std;

struct Nodo {
    string etiqueta;
    Nodo* padre;
    Nodo* hijoIzquierdo;
    Nodo* hermanoDerecho;
};

// 1. Función requerida: crearRaiz()
Nodo* crearRaiz(string etiqueta) {
    Nodo* nuevo = new Nodo;
    nuevo->etiqueta = etiqueta;
    nuevo->padre = NULL;
    nuevo->hijoIzquierdo = NULL;
    nuevo->hermanoDerecho = NULL;
    return nuevo;
}

// 2. Función requerida: insertarHijo()
// Inserta los hijos manteniendo el orden de izquierda a derecha
Nodo* insertarHijo(Nodo* padre, string etiqueta) {
    Nodo* nuevo = new Nodo;
    nuevo->etiqueta = etiqueta;
    nuevo->padre = padre;
    nuevo->hijoIzquierdo = NULL;
    nuevo->hermanoDerecho = NULL;

    if (padre->hijoIzquierdo == NULL) {
        padre->hijoIzquierdo = nuevo;
    } else {
        Nodo* actual = padre->hijoIzquierdo;
        while (actual->hermanoDerecho != NULL) {
            actual = actual->hermanoDerecho;
        }
        actual->hermanoDerecho = nuevo;
    }
    return nuevo;
}

// Reto adicional: función mostrarHijos
void mostrarHijos(Nodo* nodo) {
    if (nodo == NULL) return;
    
    Nodo* actual = nodo->hijoIzquierdo;
    while (actual != NULL) {
        cout << actual->etiqueta << endl;
        actual = actual->hermanoDerecho;
    }
}

int main() {
    // Construcción usando ÚNICAMENTE las funciones (Cero "new Nodo" en el main)
    Nodo* A = crearRaiz("A");
    Nodo* B = insertarHijo(A, "B");
    Nodo* C = insertarHijo(A, "C");
    Nodo* D = insertarHijo(A, "D");

    Nodo* E = insertarHijo(B, "E");
    Nodo* F = insertarHijo(B, "F");

    Nodo* G = insertarHijo(D, "G");

    // Impresión requerida
    cout << "Raiz: " << A->etiqueta << endl;
    cout << endl;

    cout << "Hijos de A:" << endl;
    mostrarHijos(A); 
    cout << endl;

    cout << "Hijos de B:" << endl;
    mostrarHijos(B);
    cout << endl;

    cout << "Hijos de D:" << endl;
    mostrarHijos(D);
    cout << endl;

    // Comprobación del atributo padre
    cout << "Padre de E: " << E->padre->etiqueta << endl;
    cout << "Padre de F: " << F->padre->etiqueta << endl;
    cout << "Padre de G: " << G->padre->etiqueta << endl;

    return 0;
}