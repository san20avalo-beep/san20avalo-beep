// Tarea de Nodos Enlazados

#include <iostream>

using namespace std;

struct Nodo {
    string codigo;
    string nombre;
    double precio;
    Nodo* siguiente;
};

int main() {
    Nodo* lista = NULL; 
    int cantidad;

    cout << "Cuantos productos desea registrar?: ";
    cin >> cantidad;

    // Ciclo para solicitar los datos e insertar cada nodo en la lista
    for (int i = 1; i <= cantidad; i++) {
        string codigo;
        string nombre;
        double precio;

        cout << "\nProducto " << i << "\n";
        cout << "Codigo: ";
        cin >> codigo;

        cout << "Nombre: ";
        cin >> nombre;

        cout << "Precio: ";
        cin >> precio;

        // Aqui cree el nodo dinamico dentro del ciclo
        Nodo* nuevo = new Nodo;
        nuevo->codigo = codigo;
        nuevo->nombre = nombre;
        nuevo->precio = precio;
        nuevo->siguiente = NULL;

        // Aqui se inserta al final de la fila
        if (lista == NULL) {
            lista = nuevo;
        } else {
            Nodo* aux = lista;
            while (aux->siguiente != NULL) {
                aux = aux->siguiente;
            }
            aux->siguiente = nuevo;
        }
    } // Aquí termina el ciclo for

    cout << "\n===== LISTA DE PRODUCTOS =====\n\n";
    Nodo* aux = lista;
    while (aux != NULL) {
        cout << aux->codigo << "\t"
             << aux->nombre << "\t"
             << "L." << aux->precio << "\n";
        aux = aux->siguiente;
    }

    // Aqui muestro los productos mas caros
    if (lista != NULL) {
        Nodo* masCaro = lista;
        aux = lista->siguiente;

        while (aux != NULL) {
            if (aux->precio > masCaro->precio) {
                masCaro = aux;
            }
            aux = aux->siguiente;
        }

        cout << "\nProducto mas caro:\n";
        cout << masCaro->nombre << " - L." << masCaro->precio << "\n";
    }

    // Aqui muestro el precio total de los productos
    double total = 0;
    aux = lista;
    while (aux != NULL) {
        total += aux->precio;
        aux = aux->siguiente;
    }

    cout << "\nTotal del inventario: L." << total << "\n";

    return 0;
}