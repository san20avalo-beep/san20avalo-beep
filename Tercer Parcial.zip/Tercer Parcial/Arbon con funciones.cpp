#include <iostream>
#include <string>

using namespace std;

struct Nodo {
    string etiqueta;
    Nodo * padre;
    Nodo * hijoIzquierdo;
    Nodo * hermanoDerecho;
    Nodo * hojaIzquierdo;
};

// Crear la raíz
Nodo * crearRaiz(string etiqueta) {
    Nodo * nuevo = new Nodo;
    nuevo->etiqueta = etiqueta;
    nuevo->padre = NULL;
    nuevo->hijoIzquierdo = NULL;
    nuevo->hermanoDerecho = NULL;
    nuevo->hojaIzquierdo = NULL;
    return nuevo;
}

// Insertar un hijo a la izquierda (el más reciente pasa al frente)
Nodo * insertarHijoIzquierdo(Nodo * padre, string etiqueta) {
    Nodo * nuevo = new Nodo;
    nuevo->etiqueta = etiqueta;
    nuevo->padre = padre;
    nuevo->hijoIzquierdo = NULL;
    nuevo->hermanoDerecho = padre->hijoIzquierdo;
    nuevo->hojaIzquierdo = NULL;
    
    padre->hijoIzquierdo = nuevo;
    return nuevo;
}

// Función para insertar hojas/hijos dentro de un hermano o nodo específico
Nodo * insertarHojaIzquierda(Nodo * padre, string etiqueta) {
    return insertarHijoIzquierdo(padre, etiqueta);
}

int main() {
    // 1. Crear la raíz
    Nodo * raiz = crearRaiz("RAIZ");
    
    // 2. Insertar hijos de la raíz (se van insertando al inicio, resultando en E D C B A)
    Nodo * nodoA = insertarHijoIzquierdo(raiz, "A");
    Nodo * nodoB = insertarHijoIzquierdo(raiz, "B");
    Nodo * nodoC = insertarHijoIzquierdo(raiz, "C");
    Nodo * nodoD = insertarHijoIzquierdo(raiz, "D");
    Nodo * nodoE = insertarHijoIzquierdo(raiz, "E");
    
    // 3. Insertar las hojas en el nodo A (al insertar F y luego G, resulta en G F)
    insertarHojaIzquierda(nodoA, "F");
    insertarHojaIzquierda(nodoA, "G");

    // 4. Imprimir hijos de la raíz
    cout << "Hijos de la raiz:" << endl;
    Nodo * actual = raiz->hijoIzquierdo;
    while (actual != NULL) {
        cout << "  " << actual->etiqueta;
        actual = actual->hermanoDerecho;
    }
    cout << endl;
    
    // 5. Imprimir hojas de A
    cout << "Hojas de " << nodoA->etiqueta << ":";
    Nodo * hojaActual = nodoA->hijoIzquierdo;
    while (hojaActual != NULL) {
        cout << "  " << hojaActual->etiqueta;
        hojaActual = hojaActual->hermanoDerecho;
    }
    cout << endl;
        
    return 0;   
}