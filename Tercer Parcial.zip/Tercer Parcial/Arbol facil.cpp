#include <iostream>
using namespace std;

struct Nodo {
	int dato;
	Nodo * izquierdo;
	Nodo * centro;
	Nodo * derecho;
};

int main(){
	
	Nodo * raiz = new Nodo();
	Nodo * nodo1 = new Nodo();
	Nodo * nodo2 = new Nodo();
	Nodo * nodo3 = new Nodo(); // Nuevo nodo creado
	
	raiz -> dato = 10;
	nodo1 -> dato = 5;
	nodo2 -> dato = 20;
	nodo3 -> dato = 50; // Valor del nuevo nodo
	
	raiz -> izquierdo = nodo1;
	raiz -> centro = nodo3;
	raiz -> derecho = nodo2;
	
	nodo1 -> izquierdo = NULL;
	nodo1 -> centro = NULL;
	nodo1 -> derecho = NULL;
	
	nodo2 -> izquierdo = NULL;
	nodo2 -> centro = NULL;
	nodo2 -> derecho = NULL;
	
	nodo3 -> izquierdo = NULL;
	nodo3 -> centro = NULL;
	nodo3 -> derecho = NULL;
	
	
	cout << "        " << raiz -> dato << endl;
	cout << "      /  |  \\" << endl;
	cout << "     " << raiz -> izquierdo -> dato 
	     << "  " << raiz -> centro -> dato 
	     << "   " << raiz -> derecho -> dato << endl;
	
	return 0;
}