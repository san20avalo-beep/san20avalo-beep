#include <iostream>
using namespace std;

struct Nodo {
	int dato;
	Nodo * izquierdo;
	Nodo * derecho;
};

int main(){
	
	Nodo * raiz = new Nodo();
	Nodo * nodo1 = new Nodo();
	Nodo * nodo2 = new Nodo();
	Nodo * nodo3 = new Nodo(); 
	
	raiz -> dato = 10;
	nodo1 -> dato = 5;
	nodo2 -> dato = 15;
	nodo3 -> dato = 20; 
	
	raiz -> izquierdo = nodo1;
	raiz -> derecho = nodo2;
	
	nodo1 -> izquierdo = NULL;
	nodo1 -> derecho = NULL;
	
	nodo2 -> izquierdo = NULL;
	nodo2 -> derecho = nodo3; 
	
	nodo3 -> izquierdo = NULL;
	nodo3 -> derecho = NULL;
	
	// Mostrar el arbol
	cout << "        " << raiz -> dato << endl;
	cout << "       /   \\" << endl;
	cout << "      " << raiz -> izquierdo -> dato
	     << "     "<< raiz -> derecho -> dato << endl;
	cout << "            \\" << endl;
	cout << "             " << nodo2 -> derecho -> dato << endl;
	
	return 0;
}