//Multi Nodos

#include <iostream>
using namespace std;

struct Nodo{
	int dato;
	Nodo* siguiente;
};
int main(){
	
	Nodo * inicio = NULL;
	Nodo * nuevo, * ultimo;
	int cantidad , numero;
	
	cout<<"Cuantos Nodos desea crear: ";
	cin>>cantidad;
	
	//Creacion de los Nodos
	for(int i=1; i<=cantidad; i++){
		nuevo = new Nodo;
		cout <<"Ingrese el dato para el nodo: " <<i<<": ";
		cin>>numero;
		
		nuevo -> dato = numero;
		nuevo -> siguiente = NULL;
		
		//Si es el primer Nodo
		if(inicio == NULL){
			inicio = nuevo;
			ultimo = nuevo;
		}
		else{
			ultimo -> siguiente = nuevo;
			ultimo = nuevo;
		}
	}// Aqui termina el ciclo For
	
	//Mostrar la lista de Nodos
	cout << "Los nodos que se ingresaron fueron: ";
	Nodo * aux = inicio;
	while(aux != NULL){
		cout << aux -> dato << "->";
		aux = aux -> siguiente;
	}
	
	cout << "NULL";
	
	return 0;
}