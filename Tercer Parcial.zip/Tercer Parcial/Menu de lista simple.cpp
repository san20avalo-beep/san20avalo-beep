/*Menu de lista simple*/

#include <iostream>


using namespace std;
struct Nodo{
	int dato;
	Nodo * siguiente;
};

int main(){
	Nodo* lista = nullptr;
	int op, valor;
	
	do{
		cout << "1. Insertar  2. Mostrar 3.Buscar 4.Eliminar 0.Salir: ";
		cin >> op;
		switch(op){
			case 1: cin >> valor; insertarFinal(lista , valor); 
			break;
			
			case 2: mostrar (lista);
			break;
			
			case 3: cin >> valor; buscar(lista , valor);
			break;
			
			case 4: cin >> valor; eliminar (lista , valor); 
			break;
		}
	} while (op != 0);
}