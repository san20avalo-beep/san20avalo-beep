#include <iostream>
using namespace std;

struct Nodo {
	int dato;
	Nodo * izquierdo;
	Nodo * centro;
	Nodo * derecho;
};

int main(){
	
	Nodo * raiz = new Nodo();
	Nodo * hijo1 = new Nodo();
	Nodo * hijo2 = new Nodo();
	Nodo * hijo3 = new Nodo(); 
	Nodo * nieto1 = new Nodo();
	Nodo * nieto2 = new Nodo();
	
	raiz -> dato = 10;
	hijo1 -> dato = 5;
	hijo2 -> dato = 5;
	hijo3 -> dato = 15; 
	nieto1 -> dato = 100;
	nieto2 -> dato = 20;
	
	raiz -> izquierdo = hijo1;
	raiz -> centro = hijo2;
	raiz -> derecho = hijo3;
	
	hijo1 -> izquierdo = nieto1;
	hijo1 -> centro = NULL;
	hijo1 -> derecho = NULL;
	
	hijo2 -> izquierdo = NULL;
	hijo2 -> centro = nieto2;
	hijo2 -> derecho = NULL;
	
	hijo3 -> izquierdo = NULL;
	hijo3 -> centro = NULL;
	hijo3 -> derecho = NULL;
	
	
	cout << "         " << raiz -> dato << endl;
	cout << "      /  |  \\" << endl;
	cout << "     " << raiz -> izquierdo -> dato 
	     << "    " << raiz -> centro -> dato 
	     << "    " << raiz -> derecho -> dato << endl;
	cout <<"    /     |   " << endl;
	cout <<"   "<< hijo1 -> izquierdo -> dato
	     <<"   "<<hijo2 -> centro -> dato << endl;
	
	return 0;
}