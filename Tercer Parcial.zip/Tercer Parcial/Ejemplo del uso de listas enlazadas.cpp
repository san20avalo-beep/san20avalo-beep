//Ejemplo del uso de listas enlazadas

#include <iostream>

using namespace std;
// Crear nodo

struct Nodo{
	int dato;
	Nodo* siguiente;
};

int main(){
	//Crear los nodos
	Nodo* primero = new Nodo; //Instancia de la estructura Nodo
	Nodo* segundo = new Nodo;
	Nodo* tercero = new Nodo;
	
	//Se le piden los valore al Nodo, en ves de asignarlos
	cout << "Ingrese el primer valor: ";
	cin >> primero -> dato;

	cout << "Ingrese el segundo valor: ";
	cin >> segundo -> dato;

	cout << "Ingrese el tercer valor: ";
	cin >> tercero -> dato;
	
	
	//Enlazamos los nodos 
	primero -> siguiente = segundo;
	segundo -> siguiente = tercero;  //primero--- segundo--- tercero----null
	tercero -> siguiente = NULL;
	
	//Recorrer la lista 
	Nodo* auxiliar = primero;  //Me posisiono en el primer nodo
	while(auxiliar != NULL){  //Evaluo si el nodo siguiente no es NULL
		cout<<auxiliar -> dato << endl;  //Muestro el valor del Nodo
		auxiliar = auxiliar -> siguiente;  //Paso al siguiente nodo
	}

    return 0;
}