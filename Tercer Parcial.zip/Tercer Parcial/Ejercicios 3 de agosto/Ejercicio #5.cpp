#include <iostream>
using namespace std;

struct Nodo {
    int dato;
    Nodo* izquierdo;
    Nodo* centro;
    Nodo* derecho;
};

int main() {
    Nodo* raiz = new Nodo();
    Nodo* hijo1 = new Nodo();
    Nodo* hijo2 = new Nodo();
    Nodo* hijo3 = new Nodo();
    Nodo* nieto1 = new Nodo();
    Nodo* nieto2 = new Nodo();
    Nodo* nieto3 = new Nodo();
    
    raiz->dato = 100;
    hijo1->dato = 50;
    hijo2->dato = 150;
    hijo3->dato = 200;
    nieto1->dato = 25;
    nieto2->dato = 75;
    nieto3->dato = 250;
    
    raiz->izquierdo = hijo1;
    raiz->centro = hijo2;
    raiz->derecho = hijo3;
    
    hijo1->izquierdo = nieto1;
    hijo1->centro = NULL;
    hijo1->derecho = nieto2;
    
    hijo2->izquierdo = NULL;
    hijo2->centro = NULL;
    hijo2->derecho = NULL;
    
    hijo3->izquierdo = NULL;
    hijo3->centro = nieto3;
    hijo3->derecho = NULL;
    
    nieto1->izquierdo = NULL; nieto1->centro = NULL; nieto1->derecho = NULL;
    nieto2->izquierdo = NULL; nieto2->centro = NULL; nieto2->derecho = NULL;
    nieto3->izquierdo = NULL; nieto3->centro = NULL; nieto3->derecho = NULL;
    
    cout << "          " << raiz->dato << endl;
    cout << "       /  |    \\" << endl;
    cout << "     " << hijo1->dato << "   " << hijo2->dato << "   " << hijo3->dato << endl;
    cout << "    / \\         |" << endl;
    cout << "   " << nieto1->dato << "   " << nieto2->dato << "      " << nieto3->dato << endl;
    
    return 0;
}