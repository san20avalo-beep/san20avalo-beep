/*Ejercicio #3 - Identificar hojas*/
/*Sandra Avalo*/


#include <iostream>
using namespace std;

struct Nodo{
	int dato;
	Nodo * izquierdo;
	Nodo * derecho;
};

int main(){
	Nodo * raiz = new Nodo();
	Nodo * hijo1 = new Nodo();
	Nodo * hijo2 = new Nodo();
	Nodo * hoja1 = new Nodo();
	Nodo * hoja2 = new Nodo();
	Nodo * hoja3 = new Nodo();
	Nodo * hoja4 = new Nodo();
	
	raiz -> dato = 50;
	hijo1 -> dato = 25;
	hijo2 -> dato = 75;
	hoja1 -> dato = 10;
	hoja2 -> dato = 30;
	hoja3 -> dato = 60;
	hoja4 -> dato = 90;

	
	raiz -> izquierdo = hijo1;
	raiz -> derecho = hijo2;
	
	hijo1 -> izquierdo = hoja1;
	hijo1 -> derecho = hoja2;
	
	hijo2 -> izquierdo = hoja3;
	hijo2 -> derecho = hoja4;
	
	cout << "           " << raiz -> dato << endl;
	cout << "         /    \\" << endl;
	cout << "        " << raiz -> izquierdo -> dato  
	     << "     " << raiz -> derecho -> dato << endl;
	cout <<"       / \\     / \\    " << endl;
	cout <<"      "<< hijo1 -> izquierdo -> dato;
	cout <<" "<<hijo1 -> derecho -> dato;
	cout <<"   "<<hijo2 -> izquierdo -> dato;
	cout <<"  "<<hijo2 -> derecho -> dato << endl;
	
	return 0;
}