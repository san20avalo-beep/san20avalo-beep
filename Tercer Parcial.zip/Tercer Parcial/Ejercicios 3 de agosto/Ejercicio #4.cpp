/*Ejercicio #4 - Tres hijos directos*/

#include <iostream>
using namespace std;

struct Nodo{
	int dato;
	Nodo * izquierdo;
	Nodo * centro;
	Nodo * derecho;
};

int main(){
	Nodo * raiz = new Nodo();
	Nodo * hijo1 = new Nodo();
	Nodo * hijo2 = new Nodo();
	Nodo * hijo3 = new Nodo();
	
	
	raiz -> dato = 10;
	hijo1 -> dato = 5;
	hijo2 -> dato = 20;
	hijo3 -> dato = 50;
	
	raiz -> izquierdo = hijo1;
	raiz -> centro = hijo2;
	raiz -> derecho = hijo3;
	
	hijo1 -> izquierdo = NULL;
	hijo1 -> centro = NULL;
	hijo1 -> derecho = NULL;
	
	hijo2 -> izquierdo = NULL;
	hijo2 -> centro = NULL;
	hijo2 -> derecho = NULL;
	
	hijo3 -> izquierdo = NULL;
	hijo3 -> centro = NULL;
	hijo3 -> derecho = NULL;
	
	cout << "          " << raiz -> dato << endl;
    cout << "       /   |   \\" << endl;
    cout << "      " << hijo1 -> dato << "    " << hijo2 -> dato << "    " << hijo3 -> dato << endl;
	
	return 0;
}