/*Ejercicio #2 - Agregar nuevos nodos*/
/*Sandra Avalo*/

#include <iostream>
using namespace std;

struct Nodo{
	int dato;
	Nodo * izquierdo;
	Nodo * derecho;
};

int main(){
	Nodo * raiz = new Nodo();
	Nodo * hijo1 = new Nodo();
	Nodo * hijo2 = new Nodo();
	Nodo * hoja1 = new Nodo();
	Nodo * hoja2 = new Nodo();
	Nodo * hoja3 = new Nodo();
	
	raiz -> dato = 10;
	hijo1 -> dato = 5;
	hijo2 -> dato = 15;
	hoja1 -> dato = 2;
	hoja2 -> dato = 7;
	hoja3 -> dato = 20;
	
	raiz -> izquierdo = hijo1;
	raiz -> derecho = hijo2;
	
	hijo1 -> izquierdo = hoja1;
	hijo1 -> derecho = hoja2;
	
	hijo2 -> izquierdo = NULL;
	hijo2 -> derecho = hoja3;
	
	cout << "       " << raiz -> dato << endl;
	cout << "      /   \\" << endl;
	cout << "     " << raiz -> izquierdo -> dato  
	     << "    " << raiz -> derecho -> dato << endl;
	cout <<"    / \\      \\    " << endl;
	cout <<"   "<< hijo1 -> izquierdo -> dato;
	cout <<"   "<<hijo1 -> derecho -> dato;
	     
	cout <<"     "<<hijo2 -> derecho -> dato << endl;
	
	return 0;
}