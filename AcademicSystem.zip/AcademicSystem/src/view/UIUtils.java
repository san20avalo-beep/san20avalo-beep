package view;

/**
 *
 * @author 50496
 */
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class UIUtils {
    // Paleta de Colores
    public static final Color COLOR_PRIMARY = new Color(24, 119, 242);       // Azul institucional
    public static final Color COLOR_PRIMARY_DARK = new Color(13, 71, 161);   // Azul oscuro
    public static final Color COLOR_BG = new Color(240, 242, 245);            // Fondo gris tenue
    public static final Color COLOR_CARD_BG = Color.WHITE;                    // Fondo de tarjetas
    public static final Color COLOR_TEXT_MAIN = new Color(33, 37, 41);
    public static final Color COLOR_TEXT_MUTED = new Color(108, 117, 125);
    
    // Tono Negro Oscuro para el texto de los botones
    public static final Color COLOR_TEXT_DARK = new Color(17, 17, 17);       

    // Estado de Aprobación
    public static final Color COLOR_SUCCESS = new Color(40, 167, 69);         // Verde Aprobado
    public static final Color COLOR_DANGER = new Color(220, 53, 69);          // Rojo Reprobado
    public static final Color COLOR_ACCENT = new Color(255, 193, 7);          // Amarillo / Advertencia

    // Tipografías
    public static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 20);
    public static final Font FONT_SUBTITLE = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_CARD_TITLE = new Font("Segoe UI", Font.BOLD, 12);
    public static final Font FONT_CARD_VALUE = new Font("Segoe UI", Font.BOLD, 22);

    // Crear un Panel con Gradiente
    public static JPanel crearPanelHeader(String titulo, String subtitulo) {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, COLOR_PRIMARY, getWidth(), getHeight(), COLOR_PRIMARY_DARK);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(new BorderLayout());
        panel.setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(FONT_HEADER);
        lblTitulo.setForeground(Color.WHITE);

        JLabel lblSub = new JLabel(subtitulo);
        lblSub.setFont(FONT_SUBTITLE);
        lblSub.setForeground(new Color(220, 235, 252));

        JPanel textHolder = new JPanel(new GridLayout(2, 1, 0, 3));
        textHolder.setOpaque(false);
        textHolder.add(lblTitulo);
        textHolder.add(lblSub);

        panel.add(textHolder, BorderLayout.WEST);
        return panel;
    }

    // Método para estilizar botones -> Ahora fuerza el color de texto a NEGRO OSCURO
    public static void estilizarBoton(JButton btn, Color bg) {
        btn.setBackground(bg);
        btn.setForeground(COLOR_TEXT_DARK); // Texto en negro oscuro
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(bg.darker(), 1),
            BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
    }
}
