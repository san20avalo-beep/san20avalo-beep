
package view;

/**
 *
 * @author 50496
 */
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class CardMetric extends JPanel {
    private JLabel lblValor;
    private JLabel lblTitulo;

    public CardMetric(String titulo, String valorInicial, Color colorBorde) {
        setLayout(new BorderLayout());
        setBackground(UIUtils.COLOR_CARD_BG);
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 5, 0, 0, colorBorde), // Borde lateral con color
            new EmptyBorder(12, 15, 12, 15)
        ));

        lblTitulo = new JLabel(titulo.toUpperCase());
        lblTitulo.setFont(UIUtils.FONT_CARD_TITLE);
        lblTitulo.setForeground(UIUtils.COLOR_TEXT_MUTED);

        lblValor = new JLabel(valorInicial);
        lblValor.setFont(UIUtils.FONT_CARD_VALUE);
        lblValor.setForeground(UIUtils.COLOR_TEXT_MAIN);

        add(lblTitulo, BorderLayout.NORTH);
        add(lblValor, BorderLayout.CENTER);
    }

    public void setValor(String valor) {
    lblValor.setText(valor);
    lblValor.revalidate();
    lblValor.repaint();
}
}
