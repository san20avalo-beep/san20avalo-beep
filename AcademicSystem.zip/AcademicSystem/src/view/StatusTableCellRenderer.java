
package view;

/**
 *
 * @author 50496
 */
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class StatusTableCellRenderer extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        if (!isSelected) {
            // Filas intercaladas (Efecto Zebra)
            if (row % 2 == 0) {
                c.setBackground(UIUtils.COLOR_CARD_BG);
            } else {
                c.setBackground(new java.awt.Color(248, 249, 250));
            }

            // Colorear columna de Promedio Final (columna 3)
            if (column == 3 && value != null) {
                try {
                    double nota = Double.parseDouble(value.toString().replace(",", "."));
                    if (nota >= 65.0) {
                        c.setForeground(UIUtils.COLOR_SUCCESS); // Verde
                    } else {
                        c.setForeground(UIUtils.COLOR_DANGER);  // Rojo
                    }
                } catch (NumberFormatException e) {
                    c.setForeground(UIUtils.COLOR_TEXT_MAIN);
                }
            } else {
                c.setForeground(UIUtils.COLOR_TEXT_MAIN);
            }
        }
        return c;
    }
}
