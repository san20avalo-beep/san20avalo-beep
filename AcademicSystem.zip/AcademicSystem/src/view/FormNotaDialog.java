
package view;

/**
 *
 * @author 50496
 */
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class FormNotaDialog extends JDialog {
    public JTextField txtIdEstudiante, txtNota;
    public JComboBox<String> cbParcial;
    public JButton btnGuardar, btnCancelar;

    public FormNotaDialog(Frame parent) {
        super(parent, "Asignar Nota por Parcial", true);
        setSize(420, 320);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        add(UIUtils.crearPanelHeader("Registro de Notas", "Seleccione el parcial e ingrese la calificación"), BorderLayout.NORTH);

        JPanel body = new JPanel(new GridLayout(3, 2, 10, 15));
        body.setBorder(new EmptyBorder(20, 20, 20, 20));
        body.setBackground(UIUtils.COLOR_CARD_BG);

        body.add(new JLabel("ID Estudiante:"));
        txtIdEstudiante = new JTextField();
        body.add(txtIdEstudiante);

        body.add(new JLabel("Parcial:"));
        cbParcial = new JComboBox<>(new String[]{"Parcial 1", "Parcial 2", "Parcial 3"});
        body.add(cbParcial);

        body.add(new JLabel("Nota Obtenida (0-100):"));
        txtNota = new JTextField();
        body.add(txtNota);

        add(body, BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        footer.setBackground(UIUtils.COLOR_BG);

        btnCancelar = new JButton("Cancelar");
UIUtils.estilizarBoton(btnCancelar, new Color(220, 224, 230)); 

btnGuardar = new JButton("Registrar Calificación");
UIUtils.estilizarBoton(btnGuardar, UIUtils.COLOR_SUCCESS);

        footer.add(btnCancelar);
        footer.add(btnGuardar);
        add(footer, BorderLayout.SOUTH);

        btnCancelar.addActionListener(e -> dispose());
    }
}
