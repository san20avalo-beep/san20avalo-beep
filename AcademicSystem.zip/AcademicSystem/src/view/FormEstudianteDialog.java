
package view;

/**
 *
 * @author 50496
 */
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class FormEstudianteDialog extends JDialog {
    public JTextField txtId, txtNombre;
    public JButton btnGuardar, btnCancelar;

    public FormEstudianteDialog(Frame parent) {
        super(parent, "Registrar Estudiante", true);
        setSize(420, 280);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        add(UIUtils.crearPanelHeader("Nuevo Estudiante", "Ingrese la información básica del alumno"), BorderLayout.NORTH);

        JPanel body = new JPanel(new GridLayout(2, 2, 10, 15));
        body.setBorder(new EmptyBorder(20, 20, 20, 20));
        body.setBackground(UIUtils.COLOR_CARD_BG);

        body.add(new JLabel("ID / Matrícula:"));
        txtId = new JTextField();
        body.add(txtId);

        body.add(new JLabel("Nombre Completo:"));
        txtNombre = new JTextField();
        body.add(txtNombre);

        add(body, BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        footer.setBackground(UIUtils.COLOR_BG);

        btnCancelar = new JButton("Cancelar");
        UIUtils.estilizarBoton(btnCancelar, new Color(220, 224, 230));

        btnGuardar = new JButton("Guardar");
        UIUtils.estilizarBoton(btnGuardar, UIUtils.COLOR_SUCCESS);

        footer.add(btnCancelar);
        footer.add(btnGuardar);
        add(footer, BorderLayout.SOUTH);

        btnCancelar.addActionListener(e -> dispose());
    }
}