package view;

/**
 *
 * @author 50496
 */
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class MainFrame extends JFrame {
    public JMenuItem itemNuevoEstudiante, itemAcumulativo, itemProyecto, itemExamen, itemGuardar, itemCargar;
    public JButton btnActualizar, btnNuevoEstudiante, btnAcumulativo, btnProyecto, btnExamen;
    public JTable tablaReporte;
    public DefaultTableModel tableModel;
    
    public CardMetric cardEstudiantes, cardPromedio, cardAprobados;

    public MainFrame() {
        setTitle("Sistema de Gestión Académica por Parcial");
        setSize(1000, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(UIUtils.COLOR_BG);
        setLayout(new BorderLayout());

        // --- 1. MENÚ SUPERIOR (ESTILIZADO Y MEJORADO) ---
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(Color.WHITE); // Fondo blanco limpio
        menuBar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 224, 230)), // Línea divisoria inferior
            BorderFactory.createEmptyBorder(5, 10, 5, 10) // Padding interno
        ));

        Font menuFont = new Font("Segoe UI", Font.BOLD, 13);
        Color menuTextColor = new Color(33, 37, 41);

        // Menú 1: Datos del Sistema
        JMenu menuArchivo = new JMenu("Datos del Sistema");
        menuArchivo.setFont(menuFont);
        menuArchivo.setForeground(menuTextColor);

        itemGuardar = new JMenuItem("💾 Guardar Persistencia");
        itemCargar = new JMenuItem("📂 Cargar Datos Guardados");

        menuArchivo.add(itemGuardar);
        menuArchivo.add(itemCargar);

        // Menú 2: Calificaciones y Alumnos
        JMenu menuGestion = new JMenu("Calificaciones y Alumnos");
        menuGestion.setFont(menuFont);
        menuGestion.setForeground(menuTextColor);

        itemNuevoEstudiante = new JMenuItem("👤 Registrar Estudiante...");
        itemAcumulativo = new JMenuItem("📌 Registrar Acumulativo...");
        itemProyecto = new JMenuItem("💻 Registrar Proyecto...");
        itemExamen = new JMenuItem("📄 Registrar Examen...");

        menuGestion.add(itemNuevoEstudiante);
        menuGestion.addSeparator();
        menuGestion.add(itemAcumulativo);
        menuGestion.add(itemProyecto);
        menuGestion.add(itemExamen);

        // Agregar menús con un pequeño separador
        menuBar.add(menuArchivo);
        menuBar.add(Box.createRigidArea(new Dimension(15, 0))); // Separación entre ítems
        menuBar.add(menuGestion);

        setJMenuBar(menuBar);

        // --- 2. HEADER ---
        JPanel headerPanel = UIUtils.crearPanelHeader(
            "Sistema de Calificaciones por Parcial",
            "Cómputo de acumulativos, proyectos, exámenes y promedios finales"
        );
        
        // --- 3. METRICAS ---
        JPanel metricsPanel = new JPanel(new GridLayout(1, 3, 15, 0));
        metricsPanel.setOpaque(false);
        metricsPanel.setBorder(new EmptyBorder(15, 20, 15, 20));

        cardEstudiantes = new CardMetric("Total Estudiantes", "0", UIUtils.COLOR_PRIMARY);
        cardPromedio = new CardMetric("Promedio General", "0.00", UIUtils.COLOR_ACCENT);
        cardAprobados = new CardMetric("Total Aprobados", "0", UIUtils.COLOR_SUCCESS);

        metricsPanel.add(cardEstudiantes);
        metricsPanel.add(cardPromedio);
        metricsPanel.add(cardAprobados);

        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.setOpaque(false);
        topContainer.add(headerPanel, BorderLayout.NORTH);
        topContainer.add(metricsPanel, BorderLayout.SOUTH);
        add(topContainer, BorderLayout.NORTH);

        // --- 4. TABLA CENTRAL ---
        tableModel = new DefaultTableModel(new Object[]{"ID Estudiante", "Nombre Completo", "Parcial", "Promedio Final"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablaReporte = new JTable(tableModel);
        tablaReporte.setRowHeight(30);
        tablaReporte.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        tablaReporte.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tablaReporte.getTableHeader().setBackground(new Color(220, 235, 252)); 
        tablaReporte.getTableHeader().setForeground(Color.BLACK); 
        tablaReporte.getTableHeader().setReorderingAllowed(false);

        StatusTableCellRenderer renderer = new StatusTableCellRenderer();
        for (int i = 0; i < tablaReporte.getColumnCount(); i++) {
            tablaReporte.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }

        JScrollPane scrollPane = new JScrollPane(tablaReporte);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(0, 20, 10, 20));
        scrollPane.getViewport().setBackground(UIUtils.COLOR_BG);
        add(scrollPane, BorderLayout.CENTER);

        // --- 5. PANEL INFERIOR CON LOS BOTONES ---
        JPanel panelBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 15));
        panelBottom.setBackground(UIUtils.COLOR_BG);

        btnNuevoEstudiante = new JButton("+ Estudiante");
        UIUtils.estilizarBoton(btnNuevoEstudiante, UIUtils.COLOR_PRIMARY);

        btnAcumulativo = new JButton("+ Acumulativo");
        UIUtils.estilizarBoton(btnAcumulativo, new Color(23, 162, 184)); // Azul turquesa

        btnProyecto = new JButton("+ Proyecto");
        UIUtils.estilizarBoton(btnProyecto, new Color(111, 66, 193));  // Púrpura

        btnExamen = new JButton("+ Examen");
        UIUtils.estilizarBoton(btnExamen, UIUtils.COLOR_ACCENT);

        btnActualizar = new JButton("Actualizar Datos");
        UIUtils.estilizarBoton(btnActualizar, UIUtils.COLOR_SUCCESS);

        panelBottom.add(btnNuevoEstudiante);
        panelBottom.add(btnAcumulativo);
        panelBottom.add(btnProyecto);
        panelBottom.add(btnExamen);
        panelBottom.add(btnActualizar);
        add(panelBottom, BorderLayout.SOUTH);
    }
}