package modelo.exception;

/**
 *
 * @author 50496
 */
public class NotaFueraDeRangoException extends Exception {
    public NotaFueraDeRangoException(String mensaje) {
        super(mensaje);
    }
}
