package model.entity;

/**
 *
 * @author 50496
 */
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Asignatura implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String codigo;
    private String nombre;
    // Asocia el ID del Estudiante con un mapa de Parciales (Parcial 1, 2, 3...)
    private Map<String, Map<Integer, Parcial>> registroNotas;

    public Asignatura(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.registroNotas = new HashMap<>();
    }

    public void registrarNotaParcial(String idEstudiante, int numParcial, Parcial parcial) {
        registroNotas.putIfAbsent(idEstudiante, new HashMap<>());
        registroNotas.get(idEstudiante).put(numParcial, parcial);
    }

    public double calcularNotaFinalEstudiante(String idEstudiante) {
    Map<Integer, Parcial> parciales = registroNotas.get(idEstudiante);
    if (parciales == null || parciales.isEmpty()) {
        return 0.0;
    }

    double sumaParciales = 0.0;
    for (Parcial p : parciales.values()) {
        sumaParciales += p.calcularNotaParcial();
    }

    // Calcula el promedio en función del total de parciales ingresados
    return sumaParciales / parciales.size();
}

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public Map<String, Map<Integer, Parcial>> getRegistroNotas() { return registroNotas; }
}
