package model.entity;

/**
 *
 * @author 50496
 */
import java.io.Serializable;

public abstract class Evaluacion implements Serializable {
    private static final long serialVersionUID = 1L;
    
    protected String nombre;
    protected double nota;
    protected double pesoPorcentaje;

    public Evaluacion(String nombre, double nota, double pesoPorcentaje) {
        this.nombre = nombre;
        this.nota = nota;
        this.pesoPorcentaje = pesoPorcentaje;
    }

    public abstract double calcularPuntosObtenidos();

    public String getNombre() { return nombre; }
    public double getNota() { return nota; }
    public double getPesoPorcentaje() { return pesoPorcentaje; }
}
