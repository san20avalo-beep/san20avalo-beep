package model.entity;

/**
 *
 * @author 50496
 */
public class Examen extends Evaluacion {
    public Examen(String nombre, double nota, double pesoPorcentaje) {
        super(nombre, nota, pesoPorcentaje);
    }

    @Override
    public double calcularPuntosObtenidos() {
        return (nota * pesoPorcentaje) / 100.0;
    }
}
