
package model.entity;

/**
 *
 * @author 50496
 */
public class Proyecto extends Evaluacion {
    public Proyecto(String nombre, double nota) {
        super(nombre, nota, 30.0); // Peso máximo del 30%
    }

    @Override
    public double calcularPuntosObtenidos() {
        return (nota * pesoPorcentaje) / 100.0;
    }
}
