package model.entity;

/**
 *
 * @author 50496
 */
import modelo.exception.NotaFueraDeRangoException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Parcial implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int numeroParcial;
    private List<Evaluacion> evaluaciones;

    public Parcial(int numeroParcial) {
        this.numeroParcial = numeroParcial;
        this.evaluaciones = new ArrayList<>();
    }

    public void agregarEvaluacion(Evaluacion ev) throws NotaFueraDeRangoException {
        if (ev.getNota() < 0 || ev.getNota() > 100) {
            throw new NotaFueraDeRangoException("La nota debe estar entre 0 y 100.");
        }
        evaluaciones.add(ev);
    }

    public double calcularNotaParcial() {
        double total = 0;
        for (Evaluacion ev : evaluaciones) {
            total += ev.calcularPuntosObtenidos();
        }
        return total;
    }

    public int getNumeroParcial() { return numeroParcial; }
    public List<Evaluacion> getEvaluaciones() { return evaluaciones; }
}
