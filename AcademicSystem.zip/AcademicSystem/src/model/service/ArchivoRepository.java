package model.service;

/**
 *
 * @author 50496
 */
import java.io.*;
import java.util.List;

public class ArchivoRepository {
    
    @SuppressWarnings("unchecked")
    public static <T> List<T> cargarDatos(String rutaArchivo) {
        File file = new File(rutaArchivo);
        if (!file.exists()) return null;
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (List<T>) ois.readObject();
        } catch (Exception e) {
            System.err.println("Error al cargar datos: " + e.getMessage());
            return null;
        }
    }

    public static <T> void guardarDatos(String rutaArchivo, List<T> datos) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(rutaArchivo))) {
            oos.writeObject(datos);
        } catch (IOException e) {
            System.err.println("Error al guardar datos: " + e.getMessage());
        }
    }
}
