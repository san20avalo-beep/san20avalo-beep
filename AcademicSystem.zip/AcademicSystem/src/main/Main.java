
package main;

/**
 *
 * @author 50496
 */
import controller.AcademicoController;
import view.MainFrame;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Activa el Look & Feel nativo del sistema
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            MainFrame vista = new MainFrame();
            new AcademicoController(vista);
            vista.setVisible(true);
        });
    }
}
