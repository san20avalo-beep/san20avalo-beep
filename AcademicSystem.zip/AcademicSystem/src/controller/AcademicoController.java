
package controller;

/**
 *
 * @author 50496
 */
import model.entity.*;
import modelo.exception.NotaFueraDeRangoException;
import model.service.ArchivoRepository;
import view.*;

import javax.swing.*;
import java.util.*;

public class AcademicoController {
    private MainFrame vista;
    private List<Estudiante> estudiantes;
    private Asignatura asignatura;
    private final String RUTA_ARCHIVO = "datos_academicos.dat";

    public AcademicoController(MainFrame vista) {
        this.vista = vista;
        this.estudiantes = new ArrayList<>();
        this.asignatura = new Asignatura("INF-101", "Programación Orientada a Objetos");

        initController();
        actualizarTabla();
    }

    private void initController() {
        // Registro de estudiantes
        vista.itemNuevoEstudiante.addActionListener(e -> abrirFormularioEstudiante());
        vista.btnNuevoEstudiante.addActionListener(e -> abrirFormularioEstudiante());

        // Registro de evaluaciones
        vista.itemAcumulativo.addActionListener(e -> abrirFormularioAcumulativo());
        vista.btnAcumulativo.addActionListener(e -> abrirFormularioAcumulativo());

        vista.itemProyecto.addActionListener(e -> abrirFormularioProyecto());
        vista.btnProyecto.addActionListener(e -> abrirFormularioProyecto());

        vista.itemExamen.addActionListener(e -> abrirFormularioExamen());
        vista.btnExamen.addActionListener(e -> abrirFormularioExamen());

        // Botón de Actualizar Datos y Menú
        vista.btnActualizar.addActionListener(e -> {
            actualizarTabla();
            JOptionPane.showMessageDialog(vista, "Tabla e indicadores actualizados correctamente.", "Tabla Actualizada", JOptionPane.INFORMATION_MESSAGE);
        });
        
        vista.itemGuardar.addActionListener(e -> guardarPersistencia());
        vista.itemCargar.addActionListener(e -> cargarPersistencia());
    }

    private void abrirFormularioEstudiante() {
        FormEstudianteDialog dialog = new FormEstudianteDialog(vista);
        dialog.btnGuardar.addActionListener(e -> {
            String id = dialog.txtId.getText().trim();
            String nombre = dialog.txtNombre.getText().trim();

            if (id.isEmpty() || nombre.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Complete todos los campos.", "Atención", JOptionPane.WARNING_MESSAGE);
                return;
            }

            boolean existe = estudiantes.stream().anyMatch(est -> est.getId().equalsIgnoreCase(id));
            if (existe) {
                JOptionPane.showMessageDialog(dialog, "El ID ingresado ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            estudiantes.add(new Estudiante(id, nombre));
            JOptionPane.showMessageDialog(dialog, "Estudiante registrado con éxito.");
            dialog.dispose();
            actualizarTabla();
        });
        dialog.setVisible(true);
    }

    private void abrirFormularioAcumulativo() {
        FormAcumulativoDialog dialog = new FormAcumulativoDialog(vista);
        dialog.btnGuardar.addActionListener(e -> {
            guardarEvaluacionGenerica(
                dialog, 
                dialog.txtIdEstudiante.getText().trim(), 
                dialog.cbParcial.getSelectedIndex() + 1, 
                dialog.txtNota.getText().trim(), 
                "Acumulativo"
            );
        });
        dialog.setVisible(true);
    }

    private void abrirFormularioProyecto() {
        FormProyectoDialog dialog = new FormProyectoDialog(vista);
        dialog.btnGuardar.addActionListener(e -> {
            guardarEvaluacionGenerica(
                dialog, 
                dialog.txtIdEstudiante.getText().trim(), 
                dialog.cbParcial.getSelectedIndex() + 1, 
                dialog.txtNota.getText().trim(), 
                "Proyecto"
            );
        });
        dialog.setVisible(true);
    }

    private void abrirFormularioExamen() {
        FormExamenDialog dialog = new FormExamenDialog(vista);
        dialog.btnGuardar.addActionListener(e -> {
            guardarEvaluacionGenerica(
                dialog, 
                dialog.txtIdEstudiante.getText().trim(), 
                dialog.cbParcial.getSelectedIndex() + 1, 
                dialog.txtNota.getText().trim(), 
                "Examen"
            );
        });
        dialog.setVisible(true);
    }

    // --- MÉTODOS CLAVE CORREGIDOS PARA RETENER PARCIALES PREVIOS Y ACTUALIZAR TABLA ---

    private void guardarEvaluacionGenerica(JDialog dialog, String id, int numParcial, String strNota, String tipo) {
        try {
            double nota = Double.parseDouble(strNota);

            if (nota < 0 || nota > 100) {
                throw new NotaFueraDeRangoException("La nota debe estar en el rango de [0 a 100].");
            }

            boolean existeEstudiante = estudiantes.stream().anyMatch(est -> est.getId().equalsIgnoreCase(id));
            if (!existeEstudiante) {
                JOptionPane.showMessageDialog(dialog, "Estudiante no encontrado. Regístrelo antes de asignar notas.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // 1. Obtener o crear la lista de parciales del estudiante
            Map<Integer, Parcial> mapaParciales = asignatura.getRegistroNotas().computeIfAbsent(id, k -> new HashMap<>());
            
            // 2. Obtener o crear el Parcial específico (P1, P2 o P3)
            Parcial parcial = mapaParciales.computeIfAbsent(numParcial, Parcial::new);

            // 3. Crear el objeto evaluación correspondiente
            Evaluacion eval;
            if (tipo.equals("Acumulativo")) {
                eval = new Acumulativo("Acumulativo P" + numParcial, nota);
            } else if (tipo.equals("Proyecto")) {
                eval = new Proyecto("Proyecto P" + numParcial, nota);
            } else {
                eval = new Examen("Examen P" + numParcial, nota, 40.0);
            }

            // 4. Se agrega la nota al parcial SIN borrar las de parciales anteriores
            parcial.agregarEvaluacion(eval);

            JOptionPane.showMessageDialog(dialog, tipo + " para el Parcial " + numParcial + " registrado con éxito.");
            dialog.dispose();
            
            // 5. Refrescar la tabla inmediatamente
            actualizarTabla();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(dialog, "Ingrese un número válido.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
        } catch (NotaFueraDeRangoException ex) {
            JOptionPane.showMessageDialog(dialog, ex.getMessage(), "Excepción", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void actualizarTabla() {
        // Limpiar filas de la tabla
        vista.tableModel.setRowCount(0);
        
        double sumaPromedios = 0.0;
        int aprobados = 0;
        int estudiantesConNotas = 0;

        for (Estudiante est : estudiantes) {
            double finalScore = asignatura.calcularNotaFinalEstudiante(est.getId());
            Map<Integer, Parcial> parciales = asignatura.getRegistroNotas().get(est.getId());
            
            String notaUltimoParcial = "N/A";

            if (parciales != null && !parciales.isEmpty()) {
                // Obtiene el número del último parcial evaluado
                int ultimoKey = parciales.keySet().stream().max(Integer::compareTo).orElse(1);
                notaUltimoParcial = String.format("%.2f", parciales.get(ultimoKey).calcularNotaParcial());
                
                sumaPromedios += finalScore;
                estudiantesConNotas++;

                if (finalScore >= 65.0) {
                    aprobados++;
                }
            }

            // Agregar la fila a la tabla visible
            vista.tableModel.addRow(new Object[]{
                est.getId(),
                est.getNombre(),
                notaUltimoParcial,
                String.format("%.2f", finalScore)
            });
        }

        // Refrescar tarjetas del dashboard
        int totalEstudiantes = estudiantes.size();
        double promedioGeneral = estudiantesConNotas > 0 ? (sumaPromedios / estudiantesConNotas) : 0.0;

        vista.cardEstudiantes.setValor(String.valueOf(totalEstudiantes));
        vista.cardPromedio.setValor(String.format("%.2f", promedioGeneral));
        vista.cardAprobados.setValor(String.valueOf(aprobados));

        // Forzar repintado del GUI
        vista.tablaReporte.revalidate();
        vista.tablaReporte.repaint();
    }

    private void guardarPersistencia() {
        ArchivoRepository.guardarDatos(RUTA_ARCHIVO, estudiantes);
        JOptionPane.showMessageDialog(vista, "Datos guardados exitosamente.");
    }

    @SuppressWarnings("unchecked")
    private void cargarPersistencia() {
        List<Estudiante> datosCargados = ArchivoRepository.cargarDatos(RUTA_ARCHIVO);
        if (datosCargados != null) {
            this.estudiantes = datosCargados;
            actualizarTabla();
            JOptionPane.showMessageDialog(vista, "Datos cargados correctamente.");
        }
    }
}