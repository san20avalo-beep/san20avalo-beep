package Vista;

/**
 *
 * @author Sandra Avalo
 */

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class FrmIncidencias extends JFrame {
    
    // Controles obligatorios que se solicitaron.
    private JTextField txtCuenta;
    private JTextField txtNombre;
    private JComboBox <String> cbTipo;
    private JComboBox <String> cbPrioridad;
    private JTextArea txtDescripcion;
    private JTextField txtMinutos;
    private JButton btnRegistrar;
    private JButton btnProcesar;
    private JButton btnLimpiar;
    private JLabel lblMensaje;
    private JProgressBar progressBar;
    private JTable tblIncidencias;
    private DefaultTableModel tableModel;

    public FrmIncidencias() {
        setTitle("Sistema de Atencion de Incidencias Tecnologicas UTH");
        setSize(850, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        // Este vendria siendo el panel principal
        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 10));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Este es para tener un mejor orden
        JPanel panelForm = new JPanel(new GridBagLayout());
        panelForm.setBorder(BorderFactory.createTitledBorder("Registro de Nueva Incidencia"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Fila 0
        gbc.gridx = 0; gbc.gridy = 0; panelForm.add(new JLabel("Numero de Cuenta:"), gbc);
        txtCuenta = new JTextField(15);
        gbc.gridx = 1; panelForm.add(txtCuenta, gbc);

        gbc.gridx = 2; panelForm.add(new JLabel("Nombre del Estudiante:"), gbc);
        txtNombre = new JTextField(15);
        gbc.gridx = 3; panelForm.add(txtNombre, gbc);

        // Fila 1
        gbc.gridx = 0; gbc.gridy = 1; panelForm.add(new JLabel("Tipo Incidencia:"), gbc);
        String[] tipos = {"Problema con Canvas", "Problema de conexion a internet", 
                          "Problema con cuenta institucional", "Problema con equipo de laboratorio", 
                          "Instalacion de software", "Otro"};
        cbTipo = new JComboBox<>(tipos);
        gbc.gridx = 1; 
        panelForm.add(cbTipo, gbc);

        gbc.gridx = 2; 
        panelForm.add(new JLabel("Prioridad:"), gbc);
        
        String[] prioridades = {"Baja", "Media", "Alta", "Critica"};
        cbPrioridad = new JComboBox<>(prioridades);
        gbc.gridx = 3;
        panelForm.add(cbPrioridad, gbc);

        // Fila 2
        gbc.gridx = 0; gbc.gridy = 2; 
        panelForm.add(new JLabel("Minutos Estimados:"), gbc);
        txtMinutos = new JTextField(10);
        gbc.gridx = 1; 
        panelForm.add(txtMinutos, gbc);

        // Fila 3 
        gbc.gridx = 0; gbc.gridy = 3; 
        panelForm.add(new JLabel("Descripcion:"), gbc);
        txtDescripcion = new JTextArea(3, 20);
        txtDescripcion.setLineWrap(true);
        txtDescripcion.setWrapStyleWord(true);
        JScrollPane scrollDesc = new JScrollPane(txtDescripcion);
        gbc.gridx = 1; gbc.gridwidth = 3; panelForm.add(scrollDesc, gbc);

        // Panel de Botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btnRegistrar = new JButton("Registrar Incidencia");
        btnProcesar = new JButton("Procesar Incidencia");
        btnLimpiar = new JButton("Limpiar Formulario");
        panelBotones.add(btnRegistrar);
        panelBotones.add(btnProcesar);
        panelBotones.add(btnLimpiar);

        // Panel superior que agrupa formulario y botones de control
        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.add(panelForm, BorderLayout.CENTER);
        panelSuperior.add(panelBotones, BorderLayout.SOUTH);

       
        String[] columnas = {"Código", "Cuenta", "Estudiante", "Tipo", "Prioridad", "Minutos", "Estado"};
        tableModel = new DefaultTableModel(columnas, 0) {
            
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Evita edición directa en tabla
            }
        };
        
        tblIncidencias = new JTable(tableModel);
        JScrollPane scrollTabla = new JScrollPane(tblIncidencias);

        
        JPanel panelInferior = new JPanel(new BorderLayout(5, 5));
        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        
        lblMensaje = new JLabel("Listo para operar. Ingrese una incidencia o seleccione una fila para procesar.");
        lblMensaje.setFont(new Font("SansSerif", Font.BOLD, 12));
        lblMensaje.setForeground(Color.BLUE);

        panelInferior.add(progressBar, BorderLayout.NORTH);
        panelInferior.add(lblMensaje, BorderLayout.SOUTH);

        
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);
        panelPrincipal.add(scrollTabla, BorderLayout.CENTER);
        panelPrincipal.add(panelInferior, BorderLayout.SOUTH);

        add(panelPrincipal);
    }

   
    public JTextField getTxtCuenta(){
        return txtCuenta;
    }
    
    public JTextField getTxtNombre(){
        return txtNombre;
    }
    
    public JComboBox<String> getCbTipo(){
        return cbTipo;
    }
    
    public JComboBox<String> getCbPrioridad(){
        return cbPrioridad;}
    
    public JTextArea getTxtDescripcion(){
        return txtDescripcion;
    }
    
    public JTextField getTxtMinutos(){
        return txtMinutos;
    }
    
    public JButton getBtnRegistrar(){
        return btnRegistrar;
    }
    
    public JButton getBtnProcesar(){
        return btnProcesar;
    }
    
    public JButton getBtnLimpiar(){
        return btnLimpiar;
    }
    
    public JLabel getLblMensaje(){
        return lblMensaje;
    }
    
    public JProgressBar getProgressBar(){
        return progressBar;
    }
    
    public JTable getTblIncidencias(){
        return tblIncidencias;
    }
    
    public DefaultTableModel getTableModel(){
        return tableModel;
    }
}
