package Principal;

/**
 *
 * @author Sandra Avalo
 */

import Controlador.IncidenciaController;
import Vista.FrmIncidencias;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                FrmIncidencias vista = new FrmIncidencias();
                // Instanciamos el controlador para asociarlo con la vista
                new IncidenciaController(vista);
                vista.setVisible(true);
            }
        });
    }
}
