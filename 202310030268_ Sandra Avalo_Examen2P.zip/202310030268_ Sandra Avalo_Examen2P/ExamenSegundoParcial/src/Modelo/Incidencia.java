package Modelo;

/**
 *
 * @author Sandra Avalo
 */

public class Incidencia {
    private String codigo;
    private String numeroCuenta;
    private String nombreEstudiante;
    private String tipoIncidencia;
    private String prioridad;
    private String descripcion;
    private int minutosIngresados;
    private int minutosFinales;
    private String estado; 
    
    
    //Constructor
    public Incidencia(String codigo, String numeroCuenta, String nombreEstudiante, 
                      String tipoIncidencia, String prioridad, String descripcion, int minutosIngresados) {
        this.codigo = codigo;
        this.numeroCuenta = numeroCuenta;
        this.nombreEstudiante = nombreEstudiante;
        this.tipoIncidencia = tipoIncidencia;
        this.prioridad = prioridad;
        this.descripcion = descripcion;
        this.minutosIngresados = minutosIngresados;
        this.estado = "Pendiente"; // Aqui se muestra ya el estado inicial
        calcularTiempoFinal();
    }

    public final void calcularTiempoFinal() {
        double ajuste = 1.0;
        switch (this.prioridad.toLowerCase()) {
            case "baja":
                ajuste = 1.20; // +20%
                break;
                
            case "media":
                ajuste = 1.00; // Se mantiene igual
                break;
                
            case "alta":
                ajuste = 0.80; // -20%
                break;
                
            case "critica":
                ajuste = 0.60; // -40%
                break;
        }
        this.minutosFinales = (int) Math.round(this.minutosIngresados * ajuste);
    }

   
    public void setEstado(String estado) {
        this.estado = estado;
    }

  
    public String getCodigo(){ 
        return codigo; 
    }
    
    public String getNumeroCuenta(){
        return numeroCuenta;
    }
    
    public String getNombreEstudiante(){
        return nombreEstudiante;
    }
    
    public String getTipoIncidencia(){
        return tipoIncidencia;
    }
    
    public String getPrioridad(){
        return prioridad;
    }
    
    public String getDescripcion(){
        return descripcion;
    }
    
    public int getMinutosIngresados(){
        return minutosIngresados;
    }
    
    public int getMinutosFinales(){
        return minutosFinales;
    }
    
    public String getEstado(){
        return estado;
    }
}
