package Excepciones;

/**
 *
 * @author Sandra Avalo
 */

//Excepcion personalizada
public class DatosIncidenciaException extends Exception{
    
    public DatosIncidenciaException (String mensaje){
        super(mensaje);
    }
    
}
