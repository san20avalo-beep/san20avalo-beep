package Controlador;


/**
 *
 * @author Sandra Avalo
 */

import Excepciones.DatosIncidenciaException;
import Modelo.Incidencia;
import Vista.FrmIncidencias;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class IncidenciaController {
    private final FrmIncidencias vista;
    private final List<Incidencia> listaIncidencias;
    private int contadorCorrelativo = 1;

    public IncidenciaController(FrmIncidencias vista) {
        this.vista = vista;
        this.listaIncidencias = new ArrayList<>();
        inicializarEventos();
    }

    private void inicializarEventos() {
        // Evento Registrar
        vista.getBtnRegistrar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarIncidencia();
            }
        });

        // Evento Limpiar
        vista.getBtnLimpiar().addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarCampos();
            }
        });

        // Evento Procesar
        vista.getBtnProcesar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                procesarIncidencia();
            }
        });
    }

    private void registrarIncidencia() {
        try {
            // Aqui obtengo y valido los datos
            String cuenta = vista.getTxtCuenta().getText().trim();
            String nombre = vista.getTxtNombre().getText().trim();
            String tipo = (String) vista.getCbTipo().getSelectedItem();
            String prioridad = (String) vista.getCbPrioridad().getSelectedItem();
            String descripcion = vista.getTxtDescripcion().getText().trim();
            String minutosStr = vista.getTxtMinutos().getText().trim();

            // Validaciones obligatorias
            if (cuenta.isEmpty() || nombre.isEmpty() || descripcion.isEmpty() || minutosStr.isEmpty()) {
                throw new DatosIncidenciaException("Ninguno de los campos obligatorios puede estar vacio.");
            }

            if (!cuenta.matches("\\d+") || cuenta.length() < 6) {
                throw new DatosIncidenciaException("El numero de cuenta debe contener unicamente numeros y tener como minimo 6 caracteres.");
            }

            if (nombre.length() < 3) {
                throw new DatosIncidenciaException("El nombre del estudiante debe contener al menos 3 caracteres.");
            }

            if (descripcion.length() < 10) {
                throw new DatosIncidenciaException("La descripcion debe contener al menos 10 caracteres.");
            }

            int minutos;
            try {
                minutos = Integer.parseInt(minutosStr);
            } catch (NumberFormatException ex) {
                throw new DatosIncidenciaException("El tiempo estimado debe ser un numero entero.");
            }

            if (minutos < 1 || minutos > 180) {
                throw new DatosIncidenciaException("El tiempo estimado debe estar entre 1 y 180 minutos.");
            }

            // Aquí calculo el tiempo final internamente
            String codigo = String.format("INC-%03d", contadorCorrelativo++);
            Incidencia nuevaIncidencia = new Incidencia(codigo, cuenta, nombre, tipo, prioridad, descripcion, minutos);

            // Guardo en la lista interna
            listaIncidencias.add(nuevaIncidencia);

            // Muestra el tiempo final ya calculado en la columna 5
            vista.getTableModel().addRow(new Object[]{
                    nuevaIncidencia.getCodigo(),
                    nuevaIncidencia.getNumeroCuenta(),
                    nuevaIncidencia.getNombreEstudiante(),
                    nuevaIncidencia.getTipoIncidencia(),
                    nuevaIncidencia.getPrioridad(),
                    nuevaIncidencia.getMinutosFinales() + " minutos", // Aqui agregue "minutos" para la tabla
                    nuevaIncidencia.getEstado()
            });

            // Aqui muestro el mensaje de registro 
            String mensajeExito = "Incidencia registrada con exito\n\n" +
                                  "Codigo: " + nuevaIncidencia.getCodigo() + "\n" +
                                  "Tiempo final: " + nuevaIncidencia.getMinutosFinales() + " minutos\n" +
                                  "Estado: " + nuevaIncidencia.getEstado();

            vista.getLblMensaje().setForeground(new java.awt.Color(76, 175, 80));
            vista.getLblMensaje().setText("Registro correcto. Tiempo final: " + nuevaIncidencia.getMinutosFinales() + " minutos.");
            
            JOptionPane.showMessageDialog(vista, mensajeExito, "Registro Exitoso", JOptionPane.INFORMATION_MESSAGE);

            // Aqui se limpio los campos del formulario
            limpiarCamposFormularioSolo();

        } catch (DatosIncidenciaException ex) {
            vista.getLblMensaje().setForeground(java.awt.Color.RED);
            vista.getLblMensaje().setText("Error: " + ex.getMessage());
            JOptionPane.showMessageDialog(vista, ex.getMessage(), "Error de Validacion", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void procesarIncidencia() {
        int filaSeleccionada = vista.getTblIncidencias().getSelectedRow();

        try {
            if (filaSeleccionada == -1) {
                throw new DatosIncidenciaException("Debe seleccionar una incidencia de la tabla para poder procesarla.");
            }

            String codigo = (String) vista.getTableModel().getValueAt(filaSeleccionada, 0);
            Incidencia incidencia = buscarIncidencia(codigo);

            if (incidencia == null) {
                throw new DatosIncidenciaException("No se encontro el objeto de incidencia seleccionado.");
            }

            if (!incidencia.getEstado().equals("Pendiente")) {
                throw new DatosIncidenciaException("Debe seleccionar una incidencia pendiente.");
            }

            ejecutarProcesamientoSwingWorker(incidencia, filaSeleccionada);

        } catch (DatosIncidenciaException ex) {
            vista.getLblMensaje().setForeground(java.awt.Color.RED);
            vista.getLblMensaje().setText("Error: " + ex.getMessage());
            JOptionPane.showMessageDialog(vista, ex.getMessage(), "Precaucion", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void ejecutarProcesamientoSwingWorker(final Incidencia incidencia, final int fila) {
        SwingWorker<Void, Integer> worker = new SwingWorker<Void, Integer>() {
            
            @Override
            protected Void doInBackground() throws Exception {
                incidencia.setEstado("En proceso");
                publish(0); 

                for (int i = 0; i <= 100; i += 20) {
                    Thread.sleep(400); 
                    publish(i);
                }
                
                incidencia.setEstado("Finalizada");
                return null;
            }

            @Override
            protected void process(List<Integer> chunks) {
                int ultimoValor = chunks.get(chunks.size() - 1);
                vista.getProgressBar().setValue(ultimoValor);
                
                
                vista.getTableModel().setValueAt(incidencia.getEstado(), fila, 6);
                
                vista.getLblMensaje().setForeground(new java.awt.Color(255, 152, 0)); // Naranja
                vista.getLblMensaje().setText("Procesando incidencia " + incidencia.getCodigo() + " - " + ultimoValor + "%");
            }

            @Override
            protected void done() {
                vista.getLblMensaje().setForeground(new java.awt.Color(76, 175, 80));
                vista.getLblMensaje().setText("Incidencia finalizada: " + incidencia.getCodigo());
                JOptionPane.showMessageDialog(vista, "Procesamiento Finalizado para: " + incidencia.getCodigo(), "Terminado", JOptionPane.INFORMATION_MESSAGE);
                vista.getBtnProcesar().setEnabled(true);
            }
        };

        vista.getBtnProcesar().setEnabled(false);
        worker.execute(); 
    }

    // Este limpia los campos automáticamente después de registrar (según paso 7 del requerimiento 3)
    private void limpiarCamposFormularioSolo() {
        vista.getTxtCuenta().setText("");
        vista.getTxtNombre().setText("");
        vista.getCbTipo().setSelectedIndex(0);
        vista.getCbPrioridad().setSelectedIndex(0);
        vista.getTxtDescripcion().setText("");
        vista.getTxtMinutos().setText("");
        vista.getTxtCuenta().requestFocus();
    }

 
    private void limpiarCampos() {
        limpiarCamposFormularioSolo();
        vista.getProgressBar().setValue(0);
        vista.getLblMensaje().setForeground(new java.awt.Color(0, 51, 102));
        vista.getLblMensaje().setText("Campos limpios. Formulario listo.");
    }

    private Incidencia buscarIncidencia(String codigo) {
        for (Incidencia inc : listaIncidencias) {
            if (inc.getCodigo().equals(codigo)) {
                return inc;
            }
        }
        return null;
    }
}