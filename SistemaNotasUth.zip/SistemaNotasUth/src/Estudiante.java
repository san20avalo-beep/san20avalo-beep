/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 50496 Sandra Avalo
 */
public class Estudiante {
    private String numeroCuenta;
    private String nombre;
    private double nota1;
    private double nota2;
    private double nota3;

    // Constructor vacío
    public Estudiante() {}

    // Getters y Setters con las respectivas validaciones integradas
    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        // Aqui se valida que no este vacio y que tenga una longitud minima (ej. 10 dígitos que son comunes en UTH)
        if (numeroCuenta == null || numeroCuenta.trim().isEmpty() || numeroCuenta.trim().length() < 6) {
            throw new IllegalArgumentException("El código de cuenta está incompleto o no es válido.");
        }
        this.numeroCuenta = numeroCuenta.trim();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        // Aqui se valida el nombre vacio
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del estudiante no puede estar vacío.");
        }
        this.nombre = nombre.trim();
    }

    public double getNota1() {
        return nota1;
    }

    public void setNota1(double nota1) {
        validarNota(nota1);
        this.nota1 = nota1;
    }

    public double getNota2() {
        return nota2;
    }

    public void setNota2(double nota2) {
        validarNota(nota2);
        this.nota2 = nota2;
    }

    public double getNota3() {
        return nota3;
    }

    public void setNota3(double nota3) {
        validarNota(nota3);
        this.nota3 = nota3;
    }

    // Método privado para evitar notas menores a 0 o mayores a 100
    private void validarNota(double nota) {
        if (nota < 0 || nota > 100) {
            throw new IllegalArgumentException("La nota debe estar en el rango de 0 a 100.");
        }
    }

    // Cálculo correcto del promedio final
    public double calcularPromedio() {
        return (this.nota1 + this.nota2 + this.nota3) / 3.0;
    }

    // Determina el estado del estudiante (En UTH se aprueba con 65 o 70 dependiendo de la carrera, usaremos 65 por defecto)
    public String obtenerEstado() {
        return calcularPromedio() >= 65 ? "APROBADO" : "REPROBADO";
    }
}
