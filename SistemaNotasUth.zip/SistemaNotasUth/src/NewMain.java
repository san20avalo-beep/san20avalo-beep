/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author 50496
 */

import java.util.Scanner;
public class NewMain {

    /**
     * @param args 
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Estudiante estudiante = new Estudiante();
        boolean registroExitoso = false;

        System.out.println("====================================================");
        System.out.println("  SISTEMA DE REGISTRO DE NOTAS - ACADEMICO UTH");
        System.out.println("====================================================\n");

        // Aqui comienza el registro de datos, el cual se vuelve repetitivo hasta que introduzca uno correcto
        while (!registroExitoso) {
            try {
                System.out.print("Ingrese el numero de cuenta del estudiante: ");
                String cuenta = scanner.nextLine();
                estudiante.setNumeroCuenta(cuenta);

                System.out.print("Ingrese el nombre completo del estudiante: ");
                String nombre = scanner.nextLine();
                estudiante.setNombre(nombre);
                
                registroExitoso = true; // Si llega aquí significa que los datos iniciales son válidos
            } catch (IllegalArgumentException e) {
                System.out.println("\n[ERROR] " + e.getMessage() + " Intente de nuevo.\n");
            }
        }

        System.out.println("\n--- INGRESO DE NOTAS PARCIALES ---");
        
        // Este es el ingreso de Nota1
        while (true) {
            try {
                System.out.print("Ingrese la Nota del Primer Parcial (0-100): ");
                double n1 = Double.parseDouble(scanner.nextLine());
                estudiante.setNota1(n1);
                break;
            } catch (NumberFormatException e) {
                System.out.println("[ERROR] Debe ingresar un valor numérico válido.");
            } catch (IllegalArgumentException e) {
                System.out.println("[ERROR] " + e.getMessage());
            }
        }

        // Este es el ingreso de nota2
        while (true) {
            try {
                System.out.print("Ingrese la Nota del Segundo Parcial (0-100): ");
                double n2 = Double.parseDouble(scanner.nextLine());
                estudiante.setNota2(n2);
                break;
            } catch (NumberFormatException e) {
                System.out.println("[ERROR] Debe ingresar un valor numérico válido.");
            } catch (IllegalArgumentException e) {
                System.out.println("[ERROR] " + e.getMessage());
            }
        }

        // Este es el ingreso de nota 3
        trueForm: while (true) {
            try {
                System.out.print("Ingrese la Nota del Tercer Parcial (0-100): ");
                double n3 = Double.parseDouble(scanner.nextLine());
                estudiante.setNota3(n3);
                break;
            } catch (NumberFormatException e) {
                System.out.println("[ERROR] Debe ingresar un valor numérico válido.");
            } catch (IllegalArgumentException e) {
                System.out.println("[ERROR] " + e.getMessage());
            }
        }

        // Este es el resultado y el calculo del programa
        double promedioFinal = estudiante.calcularPromedio();
        String estadoFinal = estudiante.obtenerEstado();

        System.out.println("\n====================================================");
        System.out.println("              REPORTE DE RENDIMIENTO");
        System.out.println("====================================================");
        System.out.println("Cuenta:    " + estudiante.getNumeroCuenta());
        System.out.println("Estudiante:" + estudiante.getNombre());
        System.out.printf("Notas:     [P1: %.2f]  [P2: %.2f]  [P3: %.2f]\n", 
                estudiante.getNota1(), estudiante.getNota2(), estudiante.getNota3());
        System.out.printf("Promedio:  %.2f\n", promedioFinal);
        System.out.println("Estado:    " + estadoFinal);
        System.out.println("====================================================");
        
        scanner.close();
    }
}
